import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { z } from "zod";

const mockPrices = {
  BTC: 45000,
  ETH: 2500,
  USDT: 1,
};

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Get user's wallets
  app.get("/api/wallets", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const wallets = await storage.getWalletsByUserId(req.user.id);
    res.json(wallets);
  });

  // Get user's transactions
  app.get("/api/transactions", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const transactions = await storage.getTransactionsByUserId(req.user.id);
    res.json(transactions);
  });

  // Execute trade
  app.post("/api/trade", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const tradeSchema = z.object({
      type: z.enum(["buy", "sell"]),
      currency: z.string(),
      amount: z.string(),
      price: z.string(),
    });

    const result = tradeSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const { type, currency, amount, price } = result.data;

    try {
      const transaction = await storage.createTransaction({
        userId: req.user.id,
        type,
        currency,
        amount,
        price,
        timestamp: new Date().toISOString(),
      });

      // Update wallet balance
      const wallet = await storage.getWalletByCurrency(req.user.id, currency);
      if (wallet) {
        const newBalance =
          type === "buy"
            ? Number(wallet.balance) + Number(amount)
            : Number(wallet.balance) - Number(amount);

        await storage.updateWalletBalance(wallet.id, newBalance.toString());
      } else {
        await storage.createWallet({
          userId: req.user.id,
          currency,
          balance: amount,
        });
      }

      res.json(transaction);
    } catch (error) {
      res.status(400).json({ error: "Trade failed" });
    }
  });

  // Deposit funds
  app.post("/api/deposit", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const depositSchema = z.object({
      currency: z.string(),
      amount: z.string(),
    });

    const result = depositSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const { currency, amount } = result.data;

    try {
      const transaction = await storage.createTransaction({
        userId: req.user.id,
        type: "deposit",
        currency,
        amount,
        price: mockPrices[currency as keyof typeof mockPrices].toString(),
        timestamp: new Date().toISOString(),
      });

      const wallet = await storage.getWalletByCurrency(req.user.id, currency);
      if (wallet) {
        const newBalance = Number(wallet.balance) + Number(amount);
        await storage.updateWalletBalance(wallet.id, newBalance.toString());
      } else {
        await storage.createWallet({
          userId: req.user.id,
          currency,
          balance: amount,
        });
      }

      res.json(transaction);
    } catch (error) {
      res.status(400).json({ error: "Deposit failed" });
    }
  });

  // Withdraw funds
  app.post("/api/withdraw", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const withdrawSchema = z.object({
      currency: z.string(),
      amount: z.string(),
    });

    const result = withdrawSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const { currency, amount } = result.data;

    try {
      const wallet = await storage.getWalletByCurrency(req.user.id, currency);
      if (!wallet || Number(wallet.balance) < Number(amount)) {
        return res.status(400).json({ error: "Insufficient funds" });
      }

      const transaction = await storage.createTransaction({
        userId: req.user.id,
        type: "withdraw",
        currency,
        amount,
        price: mockPrices[currency as keyof typeof mockPrices].toString(),
        timestamp: new Date().toISOString(),
      });

      const newBalance = Number(wallet.balance) - Number(amount);
      await storage.updateWalletBalance(wallet.id, newBalance.toString());

      res.json(transaction);
    } catch (error) {
      res.status(400).json({ error: "Withdrawal failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
