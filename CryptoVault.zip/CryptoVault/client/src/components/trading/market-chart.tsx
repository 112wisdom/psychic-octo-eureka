import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";

const SUPPORTED_PAIRS = [
  { symbol: "BTCUSDT", name: "BTC/USDT" },
  { symbol: "ETHUSDT", name: "ETH/USDT" },
  { symbol: "BNBUSDT", name: "BNB/USDT" },
  { symbol: "DOGEUSDT", name: "DOGE/USDT" },
  { symbol: "ADAUSDT", name: "ADA/USDT" },
];

export default function MarketChart() {
  const [selectedPair, setSelectedPair] = useState(SUPPORTED_PAIRS[0]);

  return (
    <Card className="p-6">
      <Tabs defaultValue="1D" className="w-full">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
          <div className="flex items-center gap-4">
            <select 
              className="bg-background border border-input rounded-md p-2"
              value={selectedPair.symbol}
              onChange={(e) => {
                const pair = SUPPORTED_PAIRS.find(p => p.symbol === e.target.value);
                if (pair) setSelectedPair(pair);
              }}
            >
              {SUPPORTED_PAIRS.map((pair) => (
                <option key={pair.symbol} value={pair.symbol}>
                  {pair.name}
                </option>
              ))}
            </select>
          </div>
          <TabsList>
            <TabsTrigger value="1H">1H</TabsTrigger>
            <TabsTrigger value="1D">1D</TabsTrigger>
            <TabsTrigger value="1W">1W</TabsTrigger>
            <TabsTrigger value="1M">1M</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="1D" className="mt-0">
          <div className="w-full h-[400px] flex items-center justify-center">
            <iframe
              style={{width: "100%", height: "100%"}}
              src={`https://s.tradingview.com/widgetembed/?frameElementId=tradingview_76d87&symbol=BINANCE%3A${selectedPair.symbol}&interval=D&hidesidetoolbar=1&hidetoptoolbar=1&symboledit=1&saveimage=1&toolbarbg=F1F3F6&studies=%5B%5D&hideideas=1&theme=dark&style=1&timezone=Etc%2FUTC&studies_overrides=%7B%7D&overrides=%7B%7D&enabled_features=%5B%5D&disabled_features=%5B%5D&locale=en&utm_source=coinmarketcap.com&utm_medium=widget&utm_campaign=chart&utm_term=BINANCE%3A${selectedPair.symbol}`}
            />
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
}