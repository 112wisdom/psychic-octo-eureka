import { useState } from "react";
import { useForm } from "react-hook-form";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Copy } from "lucide-react";

const SUPPORTED_CURRENCIES = [
  { symbol: "BTC", name: "Bitcoin", address: "bc1q0fra5fcl58wge2rna8v9k62ulu7u75zpcu906" },
  { symbol: "ETH", name: "Ethereum", address: "0xff87affcca06e9c56b7a2446a8bf3d02d8d" },
  { symbol: "USDT", name: "USDT (TRC20)", address: "tgrmzkdhvfkfp4fkdjumfcsehvd6xas99e" },
];

const BANK_DETAILS = {
  accountName: "Udochukwu Wisdom Chiagozie",
  accountNumber: "8026029402",
  bankName: "PalmPay",
};

type TradeFormData = {
  currency: string;
  amount: string;
  price: string;
};

export default function TradeForm() {
  const [type, setType] = useState<"buy" | "sell">("buy");
  const [showDeposit, setShowDeposit] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState(SUPPORTED_CURRENCIES[0]);

  const form = useForm<TradeFormData>({
    defaultValues: {
      currency: SUPPORTED_CURRENCIES[0].symbol,
      amount: "",
      price: "",
    },
  });

  function onSubmit(data: TradeFormData) {
    console.log(type, data);
  }

  function copyToClipboard(text: string) {
    navigator.clipboard.writeText(text);
  }

  return (
    <>
      <Card className="p-6">
        <div className="flex justify-between items-center mb-6">
          <Tabs defaultValue="buy" onValueChange={(v) => setType(v as "buy" | "sell")}>
            <TabsList className="w-full">
              <TabsTrigger value="buy" className="flex-1">Buy</TabsTrigger>
              <TabsTrigger value="sell" className="flex-1">Sell</TabsTrigger>
            </TabsList>
          </Tabs>
          <Dialog open={showDeposit} onOpenChange={setShowDeposit}>
            <DialogTrigger asChild>
              <Button variant="outline">Deposit</Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Deposit Funds</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Cryptocurrency</h3>
                  <Select
                    value={selectedCurrency.symbol}
                    onValueChange={(value) => {
                      const currency = SUPPORTED_CURRENCIES.find(c => c.symbol === value);
                      if (currency) setSelectedCurrency(currency);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SUPPORTED_CURRENCIES.map((currency) => (
                        <SelectItem key={currency.symbol} value={currency.symbol}>
                          {currency.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <div className="mt-4 p-4 bg-muted rounded-lg relative">
                    <p className="text-sm break-all">{selectedCurrency.address}</p>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="absolute right-2 top-1/2 -translate-y-1/2"
                      onClick={() => copyToClipboard(selectedCurrency.address)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Bank Transfer</h3>
                  <div className="space-y-2">
                    <p className="text-sm">Bank: {BANK_DETAILS.bankName}</p>
                    <p className="text-sm">Account Name: {BANK_DETAILS.accountName}</p>
                    <p className="text-sm">Account Number: {BANK_DETAILS.accountNumber}</p>
                  </div>
                </div>

                <Alert>
                  <AlertDescription>
                    Please contact support after making your payment for quick processing.
                  </AlertDescription>
                </Alert>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="currency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Currency</FormLabel>
                  <Select
                    value={field.value}
                    onValueChange={field.onChange}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SUPPORTED_CURRENCIES.map((currency) => (
                        <SelectItem key={currency.symbol} value={currency.symbol}>
                          {currency.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.00000001"
                      placeholder="0.00000000"
                      {...field}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="price"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Price (USD)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      {...field}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <Button type="submit" className="w-full">
              {type === "buy" ? "Buy" : "Sell"} {form.watch("currency")}
            </Button>
          </form>
        </Form>
      </Card>
    </>
  );
}