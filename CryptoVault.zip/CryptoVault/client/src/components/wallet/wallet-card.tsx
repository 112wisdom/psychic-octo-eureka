import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

type WalletCardProps = {
  currency: string;
  balance: string;
  icon: string;
};

export default function WalletCard({ currency, balance, icon }: WalletCardProps) {
  const [showDeposit, setShowDeposit] = useState(false);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{currency}</CardTitle>
        <img src={icon} alt={currency} className="h-4 w-4" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{balance}</div>
        <div className="flex gap-2 mt-4">
          <Dialog open={showDeposit} onOpenChange={setShowDeposit}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                Deposit
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Deposit {currency}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Amount</label>
                  <Input
                    type="number"
                    placeholder={`Enter ${currency} amount`}
                  />
                </div>
                <Button className="w-full">
                  Confirm Deposit
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          
          <Button variant="outline" size="sm">
            Withdraw
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
