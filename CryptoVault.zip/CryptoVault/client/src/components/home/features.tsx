import {
  Shield,
  Wallet,
  LineChart,
  Clock,
  Lock,
  RefreshCcw,
} from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

const features = [
  {
    title: "Secure Storage",
    description: "Your assets are protected with military-grade encryption",
    icon: Shield,
  },
  {
    title: "Instant Trading",
    description: "Execute trades instantly with our advanced matching engine",
    icon: LineChart,
  },
  {
    title: "Multi-Currency Support",
    description: "Trade a wide variety of cryptocurrencies",
    icon: Wallet,
  },
  {
    title: "24/7 Trading",
    description: "Markets never sleep, neither do we",
    icon: Clock,
  },
  {
    title: "Two-Factor Auth",
    description: "Enhanced security for your peace of mind",
    icon: Lock,
  },
  {
    title: "Real-time Updates",
    description: "Get instant market updates and notifications",
    icon: RefreshCcw,
  },
];

export default function Features() {
  return (
    <section className="py-24 bg-muted/50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">
          Why Choose Trust Vault
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index}>
              <CardHeader>
                <feature.icon className="h-8 w-8 mb-4 text-primary" />
                <CardTitle>{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
