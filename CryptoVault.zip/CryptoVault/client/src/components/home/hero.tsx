import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Hero() {
  return (
    <div className="relative overflow-hidden bg-background py-24">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Trade Crypto with
              <span className="text-primary block">Confidence</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Trust Vault provides a secure and intuitive platform for trading
              cryptocurrencies. Start your trading journey today.
            </p>
            <div className="flex gap-4">
              <Link href="/auth">
                <Button size="lg">Get Started</Button>
              </Link>
              <Link href="/trading">
                <Button variant="outline" size="lg">
                  View Markets
                </Button>
              </Link>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1639815189096-f75717eaecfe"
              alt="Cryptocurrency Trading"
              className="rounded-lg shadow-xl"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
