import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "Day Trader",
    image: "https://images.unsplash.com/photo-1523240795612-9a054b0db644",
    content:
      "Trust Vault has transformed how I trade crypto. The platform is intuitive and the support team is always helpful.",
  },
  {
    name: "Michael Chen",
    role: "Crypto Investor",
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c",
    content:
      "The security features and ease of use make Trust Vault my go-to platform for all my cryptocurrency trades.",
  },
  {
    name: "Emma Williams",
    role: "Portfolio Manager",
    image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85",
    content:
      "Outstanding platform with excellent features. The real-time market data and analytics are exceptional.",
  },
];

export default function Testimonials() {
  return (
    <section className="py-24">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">
          What Our Traders Say
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index}>
              <CardContent className="pt-6">
                <div className="mb-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={testimonial.image} alt={testimonial.name} />
                    <AvatarFallback>
                      {testimonial.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                </div>
                <blockquote className="text-muted-foreground mb-4">
                  "{testimonial.content}"
                </blockquote>
                <div>
                  <div className="font-semibold">{testimonial.name}</div>
                  <div className="text-sm text-muted-foreground">
                    {testimonial.role}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
