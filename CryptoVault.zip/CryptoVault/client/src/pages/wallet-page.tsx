import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import WalletCard from "@/components/wallet/wallet-card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Loader2 } from "lucide-react";

type CryptoAsset = {
  currency: string;
  balance: string;
  icon: string;
};

const cryptoAssets: CryptoAsset[] = [
  {
    currency: "BTC",
    balance: "0.00000000",
    icon: "https://cryptologos.cc/logos/bitcoin-btc-logo.svg?v=025",
  },
  {
    currency: "ETH",
    balance: "0.00000000",
    icon: "https://cryptologos.cc/logos/ethereum-eth-logo.svg?v=025",
  },
  {
    currency: "USDT",
    balance: "0.00",
    icon: "https://cryptologos.cc/logos/tether-usdt-logo.svg?v=025",
  },
];

export default function WalletPage() {
  const { data: transactions, isLoading } = useQuery<any[]>({
    queryKey: ["/api/transactions"],
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">My Wallet</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {cryptoAssets.map((asset) => (
          <WalletCard
            key={asset.currency}
            currency={asset.currency}
            balance={asset.balance}
            icon={asset.icon}
          />
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>Currency</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions?.map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell className="capitalize">{tx.type}</TableCell>
                    <TableCell>{tx.currency}</TableCell>
                    <TableCell>{tx.amount}</TableCell>
                    <TableCell>${tx.price}</TableCell>
                    <TableCell>
                      {new Date(tx.timestamp).toLocaleString()}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
